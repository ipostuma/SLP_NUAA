#include "MyPhysicsList.hh"
#include "G4VModularPhysicsList.hh"
#include "G4ParticleDefinition.hh"
#include "G4ProcessManager.hh"
#include "G4DecayPhysics.hh"
#include "G4RadioactiveDecayPhysics.hh"
#include "G4EmStandardPhysics.hh"

MyPhysicsList::MyPhysicsList() {
    // Register standard EM physics
    RegisterPhysics(new G4EmStandardPhysics());
    // Register decay physics
    RegisterPhysics(new G4DecayPhysics());
    // Register radioactive decay physics
    RegisterPhysics(new G4RadioactiveDecayPhysics());
}

MyPhysicsList::~MyPhysicsList() {}