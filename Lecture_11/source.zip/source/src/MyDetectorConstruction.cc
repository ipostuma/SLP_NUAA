// MyDetectorConstruction.cc
#include "MyDetectorConstruction.hh"
#include "G4SDManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4NistManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4PSDoseDeposit3D.hh"
#include "G4PSCellCharge3D.hh"
#include "G4VisAttributes.hh"
#include <fstream>
#include <sstream>
#include <iostream>

MyDetectorConstruction::MyDetectorConstruction(const std::string& voxelDataFile)
    : G4VUserDetectorConstruction(), fVoxelDataFile(voxelDataFile) {
    DefineMaterials();
    ReadVoxelData();
}

MyDetectorConstruction::~MyDetectorConstruction() {}

void MyDetectorConstruction::DefineMaterials() {
    G4NistManager* nist = G4NistManager::Instance();

    // Define default material (air)
    fDefaultMaterial = nist->FindOrBuildMaterial("G4_AIR");

    // Define other materials
    fMaterialMap[1] = nist->FindOrBuildMaterial("G4_WATER");
    fMaterialMap[2] = nist->FindOrBuildMaterial("G4_BONE_COMPACT_ICRU");
    // Add more materials as needed
}

void MyDetectorConstruction::ReadVoxelData() {
    std::ifstream infile(fVoxelDataFile);
    if (!infile.is_open()) {
        G4cerr << "Error opening voxel data file: " << fVoxelDataFile << G4endl;
        return;
    }

    std::string line;
    while (std::getline(infile, line)) {
        std::stringstream ss(line);
        std::vector<std::vector<int>> slice;
        std::string slice_line;
        while (std::getline(ss, slice_line, ';')) {
            std::vector<int> row;
            std::stringstream row_ss(slice_line);
            int voxel;
            while (row_ss >> voxel) {
                row.push_back(voxel);
                if (row_ss.peek() == ',') row_ss.ignore();
            }
            slice.push_back(row);
        }
        fVoxelData.push_back(slice);
    }
    infile.close();
}

G4VPhysicalVolume* MyDetectorConstruction::Construct() {

    G4VisAttributes* waterVisAtt = new G4VisAttributes(G4Colour(0.0, 0.0, 1.0,0.15));
    G4VisAttributes* boneVisAtt = new G4VisAttributes(G4Colour(0.0, 1.0, 0.0,0.15));
    std::map<int, G4VisAttributes*> VisAttMap;
    VisAttMap[1]=waterVisAtt;
    VisAttMap[2]=boneVisAtt;

    // World volume
    G4double world_size = 1.2 * 20 * cm;
    G4Box* solidWorld = new G4Box("World", world_size, world_size, world_size);
    G4LogicalVolume* logicWorld = new G4LogicalVolume(solidWorld, fDefaultMaterial, "World");
    G4VPhysicalVolume* physWorld = new G4PVPlacement(nullptr, G4ThreeVector(), logicWorld, "World", nullptr, false, 0);

    // Voxel dimensions
    G4double voxel_size = 1.0 * cm;

    // Loop through voxel data and create volumes
    G4int logic_iter = 0;
    G4double minX = fVoxelData[0][0].size() * voxel_size ;
    G4double minY = fVoxelData[0].size() * voxel_size ;
    G4double minZ = fVoxelData.size() * voxel_size ;
    for (size_t z = 0; z < fVoxelData.size(); ++z) {
        for (size_t y = 0; y < fVoxelData[z].size(); ++y) {
            for (size_t x = 0; x < fVoxelData[z][y].size(); ++x) {
                int material_id = fVoxelData[z][y][x];
                G4Material* material = fMaterialMap.count(material_id) ? fMaterialMap[material_id] : fDefaultMaterial;

                G4Box* solidVoxel = new G4Box("Voxel", voxel_size/2, voxel_size/2, voxel_size/2);
                G4LogicalVolume* logicVoxel = new G4LogicalVolume(solidVoxel, material, "Voxel");
                G4ThreeVector position(x * voxel_size - minX/2 + voxel_size/2, 
                                       y * voxel_size - minY/2 + voxel_size/2, 
                                       z * voxel_size - minZ/2 + voxel_size/2);
                new G4PVPlacement(nullptr, position, logicVoxel, "Voxel", logicWorld, false, 0);
                
                if (fMaterialMap.count(material_id)){
                    logicVoxel->SetVisAttributes(VisAttMap[material_id]);
                }
                
            }
        }
    }

    return physWorld;
}