#include "MyActionInitialization.hh"
#include "MyPrimaryGeneratorAction.hh"

void MyActionInitialization::BuildForMaster() const {
    // No master specific actions defined
}

void MyActionInitialization::Build() const {
    SetUserAction(new MyPrimaryGeneratorAction());
}
