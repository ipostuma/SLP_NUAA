#include "G4RunManager.hh"
#include "G4UImanager.hh"
#include "G4VisExecutive.hh"
#include "G4UIExecutive.hh"
#include "MyDetectorConstruction.hh"
#include "MyPhysicsList.hh"
#include "MyActionInitialization.hh"
#include "G4ScoringManager.hh"

void printUsage(const std::string &programName) {
    std::cout << "Usage: " << programName << "[options] <first_argument> " << std::endl;
    std::cout << "  [options]:" << std::endl;
    std::cout << "    --voxel <file>    Specify the voxel file" << std::endl;
    std::cout << "    -h, --help        Display this help message" << std::endl;
    std::cout << "  <first_argument>: Optional argument" << std::endl;
}

int main(int argc, char** argv) {
    // parse parameters
    // Variables to store argument values
    std::string firstArg = "/control/execute vis.mac";
    std::string voxelFile = "data_00.vox";
    bool helpFlag = false;
    int n_optional = 0;

    // Process command-line arguments
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];

        if (arg == "--help" || arg == "-h") {
            helpFlag = true;
            break;
        } else if (arg == "--voxel") {
            if (i + 1 < argc) {
                voxelFile = argv[++i];
                n_optional = n_optional + 2;
            } else {
                std::cerr << "Error: --voxel option requires a filename argument." << std::endl;
                return 1;
            }
        } else {
            // Assume the first non-option argument is the first required argument
            if (!arg.empty()) {
                firstArg = arg;
            }
            // Add more conditions here if you have more positional arguments
        }
    }

    // If help flag is set, print usage information
    if (helpFlag) {
        printUsage(argv[0]);
        return 0;
    }

    // Ensure the required argument is provided
    if (firstArg.empty()) {
        std::cerr << "Error: Missing required argument." << std::endl;
        printUsage(argv[0]);
        return 1;
    }

    // Output the arguments
    std::cout << "First argument: " << firstArg << std::endl;
    if (!voxelFile.empty()) {
        std::cout << "Voxel file: " << voxelFile << std::endl;
    }

    G4RunManager* runManager = new G4RunManager();

    // Set mandatory initialization classes
    runManager->SetUserInitialization(new MyDetectorConstruction(voxelFile));
    runManager->SetUserInitialization(new MyPhysicsList());
    runManager->SetUserInitialization(new MyActionInitialization());

    G4ScoringManager::GetScoringManager();

    // Initialize visualization
    G4VisManager* visManager = new G4VisExecutive();
    visManager->Initialize();

    // Get the pointer to the User Interface manager
    G4UImanager* UImanager = G4UImanager::GetUIpointer();

    if ((argc-n_optional) == 1) {
        // Interactive mode
        G4UIExecutive* ui = new G4UIExecutive(argc, argv);
        UImanager->ApplyCommand(firstArg);
        ui->SessionStart();
        delete ui;
    } else {
        // Batch mode
        G4String command = "/control/execute ";
        G4String fileName = firstArg;
        UImanager->ApplyCommand(command + fileName);
    }

    // Job termination
    delete visManager;
    delete runManager;
    return 0;
}