// MyDetectorConstruction.hh
#ifndef MY_DETECTOR_CONSTRUCTION_HH
#define MY_DETECTOR_CONSTRUCTION_HH

#include "G4VUserDetectorConstruction.hh"
#include "G4MultiFunctionalDetector.hh"
#include "G4LogicalVolume.hh"

class MyDetectorConstruction : public G4VUserDetectorConstruction {
public:
    MyDetectorConstruction(const std::string& voxelDataFile);
    virtual ~MyDetectorConstruction();

    virtual G4VPhysicalVolume* Construct() override;

private:
    G4LogicalVolume* flogicWaterBox;
    G4MultiFunctionalDetector* fMFD;

    std::string fVoxelDataFile = "";
    std::vector<std::vector<std::vector<int>>> fVoxelData;
    std::map<int, G4Material*> fMaterialMap;
    G4Material* fDefaultMaterial;

    void ReadVoxelData();
    void DefineMaterials();
};

#endif // MY_DETECTOR_CONSTRUCTION_HH
