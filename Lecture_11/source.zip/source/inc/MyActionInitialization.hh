#ifndef MY_ACTION_INITIALIZATION_HH
#define MY_ACTION_INITIALIZATION_HH

#include "G4VUserActionInitialization.hh"

class MyActionInitialization : public G4VUserActionInitialization {
public:
    MyActionInitialization() = default;
    virtual ~MyActionInitialization() = default;

    virtual void BuildForMaster() const override;
    virtual void Build() const override;
};

#endif // MY_ACTION_INITIALIZATION_HH
